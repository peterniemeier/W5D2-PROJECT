FactoryBot.define do
  factory :sub do
    moderator_id 1
    name "MyString"
    description "MyText"
  end
end
